# biso-0105-18
example http-server for mirea

Для запуска необходимо установить node (nodejs) версии 10 и выше

скачиваем репозитории. запусккаем команлу для установки зависимостей из ***package.json***

```npm install```

Далее для запуска используем команду:

```node index.js```

enjoy.

P.S. для отладки запросов необходимо использовать POSTMAN https://www.postman.com/downloads/

Коллекцию можно будет найти в папке postman
